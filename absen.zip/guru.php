<?php 
header ("location: \absen\auth\login.php");
?>