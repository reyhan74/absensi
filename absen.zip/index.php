<?php 
header ("location: \absen\auth\siswa\login.php");
?>